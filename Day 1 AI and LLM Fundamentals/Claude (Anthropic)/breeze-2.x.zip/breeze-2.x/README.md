This starter kit is for Laravel 11.x and prior. For our latest starter kits, check out: [https://laravel.com/starter-kits](https://laravel.com/starter-kits).
